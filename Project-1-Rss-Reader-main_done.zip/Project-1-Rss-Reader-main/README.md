# Project-1-Rss-Reader

# Group Members

* Jan Truong
* Danielle Fernandez

# Objective

The main objective of this assignment is to learn how to implement recycler view and explicit intents in Android Studio.

# Demo

In the following video you can see how the application works and a comprehensive overview of the codebase

Code Tour/Demo: [https://drive.google.com/file/d/1cbhipxGDUETBiWCJKV8fudpYdhflLVtg/view?usp=sharing]
