package com.android.example.rssreader

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.android.example.rssreader.model.Item

class TopicAdapter(private val mTopic: MutableList<FeedTopic>) : RecyclerView.Adapter<TopicAdapter.FeedViewHolder>() {

    class FeedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val entryView: CardView = itemView.findViewById(R.id.feedEntry)
        val topicView: TextView = itemView.findViewById(R.id.topic)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TopicAdapter.FeedViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.feed_topic, parent, false)
        return FeedViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mTopic.size
    }

    override fun onBindViewHolder(holder: TopicAdapter.FeedViewHolder, position: Int) {
        holder.topicView.text = mTopic[position].topic
        holder.entryView.setOnClickListener { it: View ->
                val intent = Intent(it.context, FeedActivity::class.java)
                intent.putExtra("feed", mTopic[position])
                startActivity(it.context, intent, null)
        }

    }
}