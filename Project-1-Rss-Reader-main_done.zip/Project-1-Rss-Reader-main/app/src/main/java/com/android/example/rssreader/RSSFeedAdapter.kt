package com.android.example.rssreader

import android.content.ClipData
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.android.example.rssreader.model.Item

class RSSFeedAdapter(private val mFeedList: MutableList<Item>) : RecyclerView.Adapter<RSSFeedAdapter.FeedViewHolder>() {

    class FeedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val entryView: LinearLayout = itemView.findViewById(R.id.feedEntry)
        val dateView: TextView = itemView.findViewById(R.id.date)
        val titleView: TextView = itemView.findViewById(R.id.title)
        val previewView: TextView = itemView.findViewById(R.id.preview)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeedViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.rss_feed_item, parent, false)

        return FeedViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mFeedList.size
    }

    override fun onBindViewHolder(holder: FeedViewHolder, position: Int) {
        holder.dateView.text = mFeedList[position].pubDate
        holder.titleView.text = mFeedList[position].title
        holder.previewView.text = mFeedList[position].description

        holder.entryView.setOnClickListener{
            val intent = Intent(it.context, NewsArticleActivity::class.java)
            intent.putExtra("title", mFeedList[position])
            startActivity(it.context, intent, null)
        }

    }

}