package com.android.example.rssreader

import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.example.rssreader.model.Item
import com.android.example.rssreader.model.RSSWrapper
import retrofit2.Call


class NewsArticleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_article)

        // TODO PHASE 2
        val thing = intent.getParcelableExtra<Item>("title")!!

        val textArticle  = findViewById<TextView>(R.id.article_title)
        textArticle.text = thing.title

        val textDescription  = findViewById<TextView>(R.id.article_description)
        textDescription.text = thing.description

        val textDate  = findViewById<TextView>(R.id.article_date)
        textDate.text = thing.pubDate

        val actionbar = supportActionBar
        actionbar!!.title = ""
        actionbar.setDisplayHomeAsUpEnabled(true)

        findViewById<Button>(R.id.visit_website).setOnClickListener{
            val webpage: Uri = Uri.parse(thing.link)
            val intent = Intent(Intent.ACTION_VIEW, webpage)
            startActivity(intent)
        }

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

}

